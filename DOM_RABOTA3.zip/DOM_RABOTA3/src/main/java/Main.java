

import com.mycompany.dom_rabota3.Gardener;
import com.mycompany.dom_rabota3.Plant;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String name, habitat;
        double age;
        System.out.println("Трохин Александр Андреевич");
        System.out.println("Группа РИБО-01-21");
        System.out.println();
        System.out.println("Введите название вашего растения:");
        name = scan();
        while (true) {
            System.out.println();
            System.out.println("Введите возраст вашего растения (в годах):");
            try {
                age = Double.parseDouble(scan());
                if (age < 0) {
                    System.out.println("Возраст не может быть отрицательным!");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Необходимо ввести число (необязательно целое)");
            }
        }
        System.out.println();
        System.out.println("Введите место обитания:");
        habitat = scan();
        Plant plant = new Plant(name, age, habitat);
        System.out.println();
        System.out.println("Готово! Растение создано!");
        System.out.println(plant);
        System.out.println();
        Gardener gardener = new Gardener("Alex");
        System.out.println("Вот так выглядит объект после прохождения метода filter:");
        gardener.filter(plant);
        System.out.println(plant);
    }

    public static String scan() {
        return new Scanner(System.in).nextLine();
    }
}