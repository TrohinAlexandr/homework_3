package com.mycompany.dom_rabota3;


import com.mycompany.dom_rabota3.Plant;

public class Gardener {
    private String name;

    public Gardener(String name) {
        this.name = name;
    }

    public void filter(Plant plant) {
        String[] vowel = {"e", "E", "y", "Y", "u", "U", "i", "I", "o", "O", "a", "A"};
        String name = plant.getName();
        for (String string  : vowel) {
            name = name.replace(string, "");
        }
        name = name + "VGTBL";
        plant.setName(name);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
