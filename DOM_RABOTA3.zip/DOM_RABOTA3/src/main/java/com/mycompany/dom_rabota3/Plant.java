package com.mycompany.dom_rabota3;

public class Plant {
    private String name;
    private double age;
    private String habitat;

    public Plant(String name, double age, String habitat) {
        this.name = name;
        this.age = age;
        this.habitat = habitat;
    }

    public void water() {
        System.out.println("Поливаем растение " + name);
    }

    @Override
    public String toString() {
        return "Plant{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", habitat='" + habitat + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getAge() {
        return age;
    }

    public void setAge(double age) {
        if (age < 0) {
            age = 0;
        }
        this.age = age;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }
}
